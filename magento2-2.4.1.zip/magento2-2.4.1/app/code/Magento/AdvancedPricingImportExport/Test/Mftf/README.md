# Advanced Pricing Import Export Functional Tests

The Functional Test Module for **Magento Advanced Pricing Import Export** module.
