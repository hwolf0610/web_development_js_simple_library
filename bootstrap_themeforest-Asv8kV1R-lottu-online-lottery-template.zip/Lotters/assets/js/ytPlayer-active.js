// yt player activeted
$(document).ready(function(){
    $("#bgndVideo").YTPlayer();
});
