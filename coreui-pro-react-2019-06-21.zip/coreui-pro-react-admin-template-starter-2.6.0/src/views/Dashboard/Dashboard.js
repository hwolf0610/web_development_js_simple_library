import React, { Component } from 'react';

class Dashboard extends Component {
  render() {
    return (
      <div className="animated fadeIn">
        Hello world!
      </div>
    );
  }
}

export default Dashboard;
