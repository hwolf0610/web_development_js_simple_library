import React from 'react';
import { useHistory } from "react-router-dom";
import {
  CBadge,
  CCard,
  CCardBody,
  CCardHeader,
  CCol,
  CDataTable,
  CRow
} from '@coreui/react';

import usersData from './UsersData'

const getBadge = (status) => {
  switch (status) {
    case 'Active': return 'success'
    case 'Inactive': return 'secondary'
    case 'Pending': return 'warning'
    case 'Banned': return 'danger'
    default: return 'primary'
  }
}

const Users = () => {
  const history = useHistory()
  return (
    <div className="animated fadeIn">
      <CRow>
        <CCol xl={6}>
          <CCard>
            <CCardHeader>
              Users
              <small className="text-muted"> example</small>
            </CCardHeader>
            <CCardBody>
            <CDataTable
              items={usersData}
              fields={[
                { key: 'name', _classes: 'font-weight-bold' },
                'registered', 'role', 'status']}
              hover
              striped
              pagination={{ doubleArrows: false, align: 'center' }}
              itemsPerPage={5}
              clickableRows
              onRowClick={(item, index) => history.push(`/users/${item.id}`)}
              scopedSlots = {{
                'status':
                  (item)=>(
                    <td>
                      <CBadge color={getBadge(item.status)}>
                        {item.status}
                      </CBadge>
                    </td>
                  )
              }}
            />
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>
    </div>
  )
}

export default Users
