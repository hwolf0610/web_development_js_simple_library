import DataTable from './DataTable'
import Tables from './Tables'

export { DataTable, Tables }
