// export default {
//   domain: YOUR_DOMAIN,
//   clientId: YOUR_CLIENT_ID,
// };
