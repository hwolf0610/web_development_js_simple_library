import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { useTranslation } from 'react-i18next';
import {
  Bar, CartesianGrid, ComposedChart, Line, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts';
import { Table } from 'reactstrap';
import Panel from '../../../../shared/components/Panel';
import OccupancyTooltipContent from './OccupancyTooltipContent';

const data = [
  {
    name: 'Mon 10/07',
    uv: 95,
    departure: 75,
    arrival: 10,
  },
  {
    name: 'Tue 11/07',
    uv: 85,
    departure: 23,
    arrival: 65,
  },
  {
    name: 'Wed 12/07',
    uv: 47,
    departure: 26,
    arrival: 45,
  },
  {
    name: 'Thu 13/07',
    uv: 80,
    departure: 25,
    arrival: 45,
  },
  {
    name: 'Fri 14/07',
    uv: 55,
    departure: 35,
    arrival: 15,
  },
  {
    name: 'Sat 15/07',
    uv: 99,
    departure: 30,
    arrival: 40,
  },
  {
    name: 'Sun 16/07',
    uv: 85,
    departure: 48,
    arrival: 26,
  },
];

const data01 = [
  {
    id: 0, color: 'blue', head: 'Arrivals', data: [24, 74, 54, 57, 32, 68, 53],
  },
  {
    id: 1, color: 'green', head: 'Departures', data: [75, 65, 46, 35, 65, 21, 34],
  },
  {
    id: 2, color: 'gray', head: 'Stay overs', data: [3113, 2424, 4545, 4543, 3432, 3211, 2112],
  },
  {
    id: 3, color: 'gray', head: 'Customers', data: [131, 133, 343, 342, 351, 234, 242],
  },
];

const toPercent = (decimal, fixed = 0) => `${decimal.toFixed(fixed)}%`;

const Occupancy = ({ dir, themeName }) => {
  const { t } = useTranslation('common');

  return (
    <Panel
      xl={6}
      lg={12}
      md={12}
      title={t('booking_dashboard.occupancy')}
      subhead="See how effective your business is"
    >
      <div dir="ltr">
        <ResponsiveContainer height={260}>
          <ComposedChart data={data} margin={{ top: 20, left: -15 }}>
            <XAxis dataKey="name" tickLine={false} padding={{ left: 20 }} reversed={dir === 'rtl'} />
            <YAxis tickLine={false} tickFormatter={toPercent} orientation={dir === 'rtl' ? 'right' : 'left'} />
            <Tooltip content={<OccupancyTooltipContent colorForKey={{ uv: '#555555' }} theme={themeName} />} />
            <CartesianGrid vertical={false} />
            <Bar dataKey="uv" name="Stay overs" fill="#f2f4f7" barSize={20} />
            <Line type="linear" name="Departures" dataKey="departure" stroke="#b8e986" />
            <Line type="linear" name="Arrivals" dataKey="arrival" stroke="#48b5ff" />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
      <hr />
      <div>
        <Table responsive className="table dashboard__occupancy-table">
          <tbody>
            {data01.map(items => (
              <tr>
                <td className="td-head">{items.head}</td>
                <>
                  {items.data.map(item => (
                    <td className={`td-${items.color}`}>{item}</td>
                  ))}
                </>
              </tr>
            ))}
          </tbody>
        </Table>
      </div>
    </Panel>
  );
};

Occupancy.propTypes = {
  dir: PropTypes.string.isRequired,
  themeName: PropTypes.string.isRequired,
};

export default connect(state => ({ themeName: state.theme.className }))(Occupancy);
