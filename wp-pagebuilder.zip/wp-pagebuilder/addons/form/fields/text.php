<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?> 
<span class="wppb-form-field-item wppb-form-field-input">
    <input type="text" name="wppb_default_form[<?php echo $fieldIndex; ?>]" <?php echo $fieldAttr; ?> >
</span>